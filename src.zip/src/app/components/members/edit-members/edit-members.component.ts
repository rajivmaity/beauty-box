import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-members',
  templateUrl: './edit-members.component.html',
  styleUrls: ['./edit-members.component.css']
})
export class EditMembersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
