import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-merchants',
  templateUrl: './add-merchants.component.html',
  styleUrls: ['./add-merchants.component.css']
})
export class AddMerchantsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
