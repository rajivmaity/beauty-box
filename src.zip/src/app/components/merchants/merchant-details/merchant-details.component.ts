import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-details',
  templateUrl: './merchant-details.component.html',
  styleUrls: ['./merchant-details.component.css']
})
export class MerchantDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
