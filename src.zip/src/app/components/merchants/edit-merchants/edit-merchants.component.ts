import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-merchants',
  templateUrl: './edit-merchants.component.html',
  styleUrls: ['./edit-merchants.component.css']
})
export class EditMerchantsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
