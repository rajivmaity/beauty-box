import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-templates',
  templateUrl: './edit-templates.component.html',
  styleUrls: ['./edit-templates.component.css']
})
export class EditTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
