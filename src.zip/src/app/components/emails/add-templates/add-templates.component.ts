import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-templates',
  templateUrl: './add-templates.component.html',
  styleUrls: ['./add-templates.component.css']
})
export class AddTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
