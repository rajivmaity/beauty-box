export interface Login {
    emailAddress: string;
    password: string;
    isLoginValid: boolean;
}