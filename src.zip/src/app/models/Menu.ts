export interface Menu {
    id: number;
    menuName: string;
    fontAwesomeClass: string;
    routerPath: string;
    state: boolean;
}